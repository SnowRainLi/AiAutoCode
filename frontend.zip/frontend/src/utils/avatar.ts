/**
 * 获取用户头像URL
 * 如果用户没有设置头像，返回基于用户名的默认头像
 * @param userAvatar 用户头像URL
 * @param userName 用户名（用于生成默认头像）
 * @returns 头像URL，如果为空则返回undefined让Avatar组件显示首字母
 */
export function getUserAvatar(userAvatar?: string, userName?: string): string | undefined {
  // 如果有头像，直接返回
  if (userAvatar) {
    return userAvatar
  }
  
  // 如果没有头像，返回undefined，让Avatar组件显示首字母
  // 或者可以使用在线头像生成服务
  // 例如：return `https://api.dicebear.com/7.x/initials/svg?seed=${userName || 'User'}`
  return undefined
}

/**
 * 生成基于用户名的默认头像URL（使用在线服务）
 * @param userName 用户名
 * @returns 默认头像URL
 */
export function getDefaultAvatarUrl(userName?: string): string {
  const seed = userName || 'User'
  // 使用 DiceBear API 生成头像
  return `https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(seed)}&backgroundColor=1890ff&textColor=ffffff`
}

