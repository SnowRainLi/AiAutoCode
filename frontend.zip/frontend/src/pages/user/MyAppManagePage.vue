<template>
  <div id="myAppManagePage">
    <div class="page-header">
      <h1>我的应用</h1>
      <p class="page-description">管理您创建的所有应用</p>
    </div>

    <!-- 搜索表单 -->
    <a-card class="search-card">
      <a-form layout="inline" :model="searchParams" @finish="doSearch">
        <a-form-item label="应用名称">
          <a-input
            v-model:value="searchParams.appName"
            placeholder="输入应用名称搜索"
            style="width: 250px"
            allow-clear
          />
        </a-form-item>
        <a-form-item label="生成类型">
          <a-select
            v-model:value="searchParams.codeGenType"
            placeholder="选择生成类型"
            style="width: 180px"
            allow-clear
          >
            <a-select-option
              v-for="option in CODE_GEN_TYPE_OPTIONS"
              :key="option.value"
              :value="option.value"
            >
              {{ option.label }}
            </a-select-option>
          </a-select>
        </a-form-item>
        <a-form-item>
          <a-space>
            <a-button type="primary" html-type="submit">搜索</a-button>
            <a-button @click="resetSearch">重置</a-button>
          </a-space>
        </a-form-item>
      </a-form>
    </a-card>

    <!-- 应用列表表格 -->
    <a-card class="table-card">
      <a-table
        :columns="columns"
        :data-source="data"
        :pagination="pagination"
        :loading="loading"
        @change="doTableChange"
        :scroll="{ x: 1200 }"
      >
        <template #bodyCell="{ column, record }">
          <template v-if="column.key === 'cover'">
            <div class="cover-cell">
              <img v-if="record.cover" :src="record.cover" :alt="record.appName" class="cover-image" />
              <div v-else class="no-cover">无封面</div>
            </div>
          </template>
          <template v-else-if="column.key === 'codeGenType'">
            <a-tag color="blue">{{ formatCodeGenType(record.codeGenType) }}</a-tag>
          </template>
          <template v-else-if="column.key === 'deployKey'">
            <a-tag v-if="record.deployKey" color="green">已部署</a-tag>
            <a-tag v-else color="default">未部署</a-tag>
          </template>
          <template v-else-if="column.key === 'createTime'">
            {{ formatTime(record.createTime) }}
          </template>
          <template v-else-if="column.key === 'deployedTime'">
            {{ record.deployedTime ? formatTime(record.deployedTime) : '-' }}
          </template>
          <template v-else-if="column.key === 'action'">
            <a-space>
              <a-button type="link" size="small" @click="viewDetail(record)">详情</a-button>
              <a-button type="link" size="small" @click="editApp(record)">编辑</a-button>
              <a-button type="link" size="small" @click="goToChat(record)">对话</a-button>
              <a-button
                v-if="record.deployKey"
                type="link"
                size="small"
                @click="viewWork(record)"
              >
                查看作品
              </a-button>
              <a-button
                v-else
                type="link"
                size="small"
                @click="deployApp(record)"
                :loading="deployingAppId === record.id"
              >
                部署
              </a-button>
              <a-button type="link" size="small" @click="downloadCode(record)">下载代码</a-button>
              <a-popconfirm
                title="确定要删除这个应用吗？"
                @confirm="deleteApp(record.id)"
                ok-text="确定"
                cancel-text="取消"
              >
                <a-button type="link" danger size="small">删除</a-button>
              </a-popconfirm>
            </a-space>
          </template>
        </template>
      </a-table>
    </a-card>

    <!-- 应用详情弹窗 -->
    <AppDetailModal
      :open="detailModalVisible"
      :app="selectedApp"
      :show-actions="false"
      @update:open="detailModalVisible = $event"
    />

    <!-- 编辑应用名称弹窗 -->
    <a-modal
      v-model:open="editModalVisible"
      title="编辑应用名称"
      @ok="handleEditSubmit"
      :confirm-loading="editing"
    >
      <a-form :model="editForm" layout="vertical">
        <a-form-item label="应用名称" name="appName">
          <a-input
            v-model:value="editForm.appName"
            placeholder="请输入应用名称"
            :maxlength="50"
            show-count
          />
        </a-form-item>
      </a-form>
    </a-modal>
  </div>
</template>

<script lang="ts" setup>
import { computed, onMounted, reactive, ref } from 'vue'
import { useRouter } from 'vue-router'
import { message } from 'ant-design-vue'
import {
  listMyAppVoByPage,
  deleteApp as deleteAppApi,
  updateApp,
  deployApp as deployAppApi,
  downloadAppCode,
} from '@/api/appController'
import { CODE_GEN_TYPE_OPTIONS, formatCodeGenType } from '@/utils/codeGenTypes'
import { formatTime } from '@/utils/time'
import { getDeployUrl, API_BASE_URL } from '@/config/env'
import AppDetailModal from '@/components/AppDetailModal.vue'

const router = useRouter()

// 表格列定义
const columns = [
  {
    title: 'ID',
    dataIndex: 'id',
    width: 80,
    fixed: 'left',
  },
  {
    title: '封面',
    key: 'cover',
    width: 100,
  },
  {
    title: '应用名称',
    dataIndex: 'appName',
    width: 200,
  },
  {
    title: '生成类型',
    key: 'codeGenType',
    width: 150,
  },
  {
    title: '部署状态',
    key: 'deployKey',
    width: 100,
  },
  {
    title: '创建时间',
    key: 'createTime',
    width: 180,
  },
  {
    title: '部署时间',
    key: 'deployedTime',
    width: 180,
  },
  {
    title: '操作',
    key: 'action',
    width: 400,
    fixed: 'right',
  },
]

// 数据
const data = ref<API.AppVO[]>([])
const total = ref(0)
const loading = ref(false)

// 搜索条件
const searchParams = reactive<API.AppQueryRequest>({
  pageNum: 1,
  pageSize: 10,
  appName: '',
  codeGenType: undefined,
})

// 获取数据
const fetchData = async () => {
  loading.value = true
  try {
    const res = await listMyAppVoByPage({
      ...searchParams,
    })
    if (res.data.code === 0 && res.data.data) {
      data.value = res.data.data.records ?? []
      total.value = res.data.data.totalRow ?? 0
    } else {
      message.error('获取数据失败，' + res.data.message)
    }
  } catch (error) {
    console.error('获取数据失败：', error)
    message.error('获取数据失败')
  } finally {
    loading.value = false
  }
}

// 页面加载时请求一次
onMounted(() => {
  fetchData()
})

// 分页参数
const pagination = computed(() => {
  return {
    current: searchParams.pageNum ?? 1,
    pageSize: searchParams.pageSize ?? 10,
    total: total.value,
    showSizeChanger: true,
    showTotal: (total: number) => `共 ${total} 条`,
  }
})

// 表格变化处理
const doTableChange = (page: { current: number; pageSize: number }) => {
  searchParams.pageNum = page.current
  searchParams.pageSize = page.pageSize
  fetchData()
}

// 搜索
const doSearch = () => {
  searchParams.pageNum = 1
  fetchData()
}

// 重置搜索
const resetSearch = () => {
  searchParams.appName = ''
  searchParams.codeGenType = undefined
  searchParams.pageNum = 1
  fetchData()
}

// 查看详情
const detailModalVisible = ref(false)
const selectedApp = ref<API.AppVO>()
const viewDetail = (app: API.AppVO) => {
  selectedApp.value = app
  detailModalVisible.value = true
}

// 编辑应用
const editModalVisible = ref(false)
const editing = ref(false)
const editingAppId = ref<number>()
const editForm = reactive({
  appName: '',
})

const editApp = (app: API.AppVO) => {
  editingAppId.value = app.id
  editForm.appName = app.appName || ''
  editModalVisible.value = true
}

const handleEditSubmit = async () => {
  if (!editingAppId.value) return

  editing.value = true
  try {
    const res = await updateApp({
      id: editingAppId.value,
      appName: editForm.appName,
    })

    if (res.data.code === 0) {
      message.success('修改成功')
      editModalVisible.value = false
      fetchData()
    } else {
      message.error('修改失败：' + res.data.message)
    }
  } catch (error) {
    console.error('修改失败：', error)
    message.error('修改失败')
  } finally {
    editing.value = false
  }
}

// 删除应用
const deleteApp = async (id: number | undefined) => {
  if (!id) return

  try {
    const res = await deleteAppApi({ id })
    if (res.data.code === 0) {
      message.success('删除成功')
      fetchData()
    } else {
      message.error('删除失败：' + res.data.message)
    }
  } catch (error) {
    console.error('删除失败：', error)
    message.error('删除失败')
  }
}

// 进入对话页面
const goToChat = (app: API.AppVO) => {
  if (app.id) {
    router.push(`/app/chat/${app.id}`)
  }
}

// 查看作品
const viewWork = (app: API.AppVO) => {
  if (app.deployKey) {
    const url = getDeployUrl(app.deployKey)
    window.open(url, '_blank')
  }
}

// 部署应用
const deployingAppId = ref<number>()
const deployApp = async (app: API.AppVO) => {
  if (!app.id) return

  deployingAppId.value = app.id
  try {
    const res = await deployAppApi({
      appId: app.id,
    })

    if (res.data.code === 0 && res.data.data) {
      message.success('部署成功')
      fetchData()
    } else {
      message.error('部署失败：' + res.data.message)
    }
  } catch (error) {
    console.error('部署失败：', error)
    message.error('部署失败')
  } finally {
    deployingAppId.value = undefined
  }
}

// 下载代码
const downloadCode = async (app: API.AppVO) => {
  if (!app.id) return

  try {
    // 直接触发下载
    const url = `${API_BASE_URL}/app/download/${app.id}`
    const link = document.createElement('a')
    link.href = url
    link.download = `${app.appName || app.id}.zip`
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
    message.success('开始下载')
  } catch (error) {
    console.error('下载失败：', error)
    message.error('下载失败')
  }
}
</script>

<style scoped>
#myAppManagePage {
  padding: 24px;
  background: #f0f2f5;
  min-height: calc(100vh - 64px);
}

.page-header {
  margin-bottom: 24px;
}

.page-header h1 {
  margin: 0 0 8px;
  font-size: 24px;
  font-weight: 600;
  color: #1a1a1a;
}

.page-description {
  margin: 0;
  color: #666;
  font-size: 14px;
}

.search-card {
  margin-bottom: 16px;
}

.table-card {
  background: white;
}

.cover-cell {
  display: flex;
  align-items: center;
  justify-content: center;
}

.cover-image {
  width: 80px;
  height: 60px;
  object-fit: cover;
  border-radius: 4px;
}

.no-cover {
  width: 80px;
  height: 60px;
  background: #f5f5f5;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #999;
  font-size: 12px;
  border-radius: 4px;
}

:deep(.ant-table-tbody > tr > td) {
  vertical-align: middle;
}
</style>

